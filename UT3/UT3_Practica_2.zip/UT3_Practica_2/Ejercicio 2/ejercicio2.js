function atras(){
    window.history.back();
}
function adelante(){
    window.history.forward();
}
